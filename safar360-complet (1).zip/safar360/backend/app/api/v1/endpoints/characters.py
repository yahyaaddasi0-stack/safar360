import json
import os
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Query, status

from app.schemas.character import (
    CharacterBase,
    CharacterListResponse,
    CharacterResponse,
)

router = APIRouter()

# Load characters from JSON file
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), "data")
CHARACTERS_FILE = os.path.join(DATA_DIR, "characters.json")

def load_characters():
    if os.path.exists(CHARACTERS_FILE):
        with open(CHARACTERS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

MOCK_CHARACTERS = load_characters()

@router.get(
    "/characters",
    response_model=CharacterListResponse,
    summary="Get all historical characters",
    description="Returns a simple success status and a data array of historical characters."
)
async def get_characters(
    category: Optional[str] = Query(None, description="Optional category filter (e.g. commanders, thinkers, explorers, writers, queens)")
):
    if category and category != "all":
        filtered = [c for c in MOCK_CHARACTERS if c["category"] == category]
        return CharacterListResponse(
            status="success",
            count=len(filtered),
            data=[CharacterBase(**c) for c in filtered]
        )

    return CharacterListResponse(
        status="success",
        count=len(MOCK_CHARACTERS),
        data=[CharacterBase(**c) for c in MOCK_CHARACTERS]
    )


@router.get(
    "/characters/{character_id}",
    response_model=CharacterResponse,
    summary="Get single historical character by ID",
    description="Returns detailed persona and historical facts for a specific character."
)
async def get_character_by_id(character_id: str):
    character = next((c for c in MOCK_CHARACTERS if c["id"] == character_id), None)
    if not character:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Character with ID '{character_id}' was not found in Safar 360 records."
        )
    return CharacterResponse(status="success", data=CharacterBase(**character))
