from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class TimelineEvent(BaseModel):
    year: str
    title: str
    desc: str


class ArtifactItem(BaseModel):
    name: str
    type: str
    icon: str
    desc: str


class MapLocation(BaseModel):
    name: str
    coords: List[float]
    desc: str


class CharacterBase(BaseModel):
    id: str = Field(..., description="Unique slug identifier (e.g. tariq-ibn-ziyad)")
    arabic_name: str = Field(..., description="Arabic name in calligraphy display format")
    latin_name: str = Field(..., description="Transliterated Latin name")
    title: str = Field(..., description="Historical honorary title")
    role_tag: str = Field(..., description="Short tag (e.g. قائد الفتح, أمير الرحالة)")
    category: str = Field(..., description="Category slug: commanders, writers, thinkers, explorers, queens")
    category_ar: str = Field(..., description="Arabic category name")
    era: str = Field(..., description="Historical period range (e.g. ٦٧٠ - ٧٢٠ م)")
    era_tag: str = Field(..., description="Century era tag (e.g. القرن الأول الهجري)")
    origin: str = Field(..., description="Geographic origin and birthplace")
    achievement: str = Field(..., description="Greatest landmark achievement or masterpiece")
    quote: str = Field(..., description="Iconic historical quote")
    quick_prompts: List[str] = Field(default_factory=list, description="Suggested starter questions")
    timeline: Optional[List[TimelineEvent]] = Field(default_factory=list)
    artifacts: Optional[List[ArtifactItem]] = Field(default_factory=list)
    map_locations: Optional[List[MapLocation]] = Field(default_factory=list)


class CharacterResponse(BaseModel):
    status: str = "success"
    data: CharacterBase


class CharacterListResponse(BaseModel):
    status: str = "success"
    count: int
    data: List[CharacterBase]
